/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pagereplacementalgorithms;

import java.awt.BasicStroke;
import java.awt.Color;
import java.io.IOException;
import java.util.ConcurrentModificationException;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

/**
 *
 * @author Chand
 */
public class PageReplacementAlgorithms {
    
    int pageFrameSize = 0;
    static int[] PageFrames;
    static int[] PageDefaults;
    /**
     * @param args the command line arguments
     */
    public PageReplacementAlgorithms() {
        
        
    }
    
    @SuppressWarnings("unchecked")
    public static void main(String[] args) {
        // TODO code application logic here
        //PageReplacementAlgorithms alg = new PageReplacementAlgorithms("PageDefaults vs page frames");
        AgingAlgorithm a = new AgingAlgorithm();
        try {
            PageFrames = new int[10];
            PageDefaults = new int[10];
            a.CreatePageDataFile();
            for(int i = 0; i< 10; i++){
                PageFrames[i] = (i+1)*1000;
                PageDefaults[i] = a.getPageFaults(PageFrames[i]);
            }
            for (int i = 0; i < 10; i++) {
                System.out.println("PageFrames : " + PageFrames[i] + " & Page faults :" + PageDefaults[i]);
            }
//            alg.pack();
//            RefineryUtilities.centerFrameOnScreen(alg);
//            alg.setVisible(true);
        } catch (IOException ex) {
            ex.printStackTrace();
        }catch (ConcurrentModificationException e){
            
        }
    }

    
}
