/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pagereplacementalgorithms;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import static java.lang.Math.abs;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Chand
 */
public class AgingAlgorithm {
    
    int PageSize = 4;
    HashMap<Page, Integer> myMap;
    MapUpdater updater;
    //int maxPageFrames = 1000;

    AgingAlgorithm() {
        myMap = new HashMap();
        updater = new MapUpdater();
    }

    public void CreatePageDataFile() throws IOException {
        //Get the data
        File f = new File("Sample.txt");
        if (!f.exists()) {
            f.createNewFile();
        }
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));
        for (int i = 0; i < 100000; i++) {
            String str = "";
            for (int j = 0; j < PageSize; j++) {
                Random gen = new Random();
                Integer num = gen.nextInt();
                num = abs(num % 10);
                str = str + num.toString() + " ";
            }
            bw.write(str + "\n");
        }
    }

    class MapUpdater implements Runnable {
        Thread th;
        
        MapUpdater(){
            th = new Thread(this);
            th.start();
        }

        @Override
        public void run() {
            while (true) {
                try {
                Iterator iter = myMap.entrySet().iterator();
                while (iter.hasNext()) {
                    Map.Entry e = (Map.Entry) iter.next();
                    Integer val = (Integer) e.getValue();
                    val = val >> 1;
                    myMap.replace((Page) e.getKey(), val);
                }
                
                    Thread.sleep(5000);
                } catch (InterruptedException ex) {
                    ex.printStackTrace(System.out);
                }catch (ConcurrentModificationException e){
            
        }
            }
        }

    }

    public int getPageFaults(int maxPageFrames) throws FileNotFoundException, IOException {
        int NopageFaults = 0;
        BufferedReader br = new BufferedReader(new FileReader("Sample.txt"));
        String str = br.readLine();
        while (str != null) {
            String[] snums = str.split(" ");
            Page p = new Page();
            for (String snum : snums) {
                int x = Integer.parseInt(snum);
                p.addNumber(x);
            }
            boolean pageFound = false;
            Iterator iter = myMap.entrySet().iterator();
            Page foundPage = null;
            while (iter.hasNext()) {
                Map.Entry e = (Map.Entry)iter.next();
                foundPage = (Page)e.getKey();
                if (foundPage.equals(p)) {
                    pageFound = true;
                    break;
                }
            }
            if (pageFound) {
                int val = myMap.get(foundPage);
                if (val < 128) {
                    myMap.replace(p, val += 128);
                }
            } else {
                NopageFaults++;
                if (myMap.size() < maxPageFrames) {
                    myMap.put(p, 128);
                } else {
                    int min = 128;
                    iter = myMap.entrySet().iterator();
                    Page pageTobeRemoved = null;
                    while (iter.hasNext()) {
                        Map.Entry entry = (Map.Entry) iter.next();
                        int val = (Integer) entry.getValue();
                        if (val == 0) {
                            pageTobeRemoved = (Page) entry.getKey();
                            myMap.put(p, 128);
                            break;
                        } else if (val <= min) {
                            min = val;
                            pageTobeRemoved = (Page) entry.getKey();
                        }
                    }
                    if (pageTobeRemoved != null) {
                        myMap.remove(pageTobeRemoved);
                        myMap.put(p, 128);
                    } else {
                        Map.Entry e = (Map.Entry) myMap.entrySet();
                        myMap.remove((Page) e.getKey());
                        myMap.put(p, 128);
                    }
                }
            }
            str = br.readLine();
        }
        myMap.clear();
        return NopageFaults;
    }

    public class Page {

        
        int[] iPage;
        int ctr = 0;

        Page() {
            ctr = 0;
            iPage = new int[PageSize];
            for(int a : iPage){
                a = 0;
            }
        }

        boolean equals(Page p1) {
            int[] p1Contents = p1.getContents();
            for (int i = 0; i < iPage.length; i++) {
                if (p1Contents[i] != iPage[i]) {
                    return false;
                }
            }
            return true;
        }

        public int[] getContents() {
            return iPage;
        }


        void setPageSize(int p) {
            PageSize = p;
        }

        void addNumber(int x) {
            if (ctr < PageSize) {
                iPage[ctr] = x;
                ctr++;
            }
        }
    }

}
