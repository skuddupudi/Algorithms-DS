/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankersalgorithm;

import java.util.Scanner;

/**
 *
 * @author Chand
 */
public class BankersAlgorithm {

    /****************************
     *  Variable declaraions    *
     ****************************/
    int Existing[];
    int Available[];
    int CurrentRes[][];
    int MaxRequiredRes[][];
    int NOR;
    int NOP;
    
    /**
     * Constructor for this class
     * Input arguments : 
     * maximum available resources           int[]
     * number of processes being checked     int
     */
    BankersAlgorithm(int[] maxres, int NOP) {
        Existing = maxres;
        NOR = Existing.length;
        this.NOP = NOP;
        Available = new int[NOR];
        CurrentRes = new int[NOP][NOR];
        MaxRequiredRes = new int[NOP][NOR];
        
    }
    
    /**
     * This method needs to be called for starting the algorithm
     * Input arguments : void
     * Return value    : void
     */
    public void start(){
        System.out.println("Please enter Max required (M[i][j]) matrix : \n");
        setMaxResMatrix();
        System.out.println("Please enter Resources to be allocated (C[i][j]) matrix : \n");
        setAllocateResource();
        buildAvailableVector();
        if(isDeadlock()){
            System.out.println("Resource allocation caused deadlock...");
            System.exit(0);
        }else{
            RunAlgorithm();
        }
    }
    
    /**
     * This method builds builds available vector from current used resources
     * matrix and maximum available resource matrix
     * Input arguments : void
     * Return value    : void
     */
    void buildAvailableVector(){
        for(int j = 0;j< NOR; j++ ){
            int curres = Existing[j];
            for(int i = 0; i < NOP; i++){
                curres -= CurrentRes[i][j];
            }
            Available[j] = curres;
        }
    }
    
    /**
     * This method is used to set Maximum resource matrix
     * Input is taken from console
     * Input arguments : void
     * Return value : void
     */
    void setMaxResMatrix() {
        Scanner sc = new Scanner(System.in);
        try {
            for (int i = 0; i < NOP; i++) {
                for (int j = 0; j < NOR; j++) {
                    MaxRequiredRes[i][j] = sc.nextInt();
                }
            }
        } catch (Exception e) {
            System.out.println("PLeas enter integer values...");
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    /**
     * This method sets the current resource allocation matrix
     * Input is taken from console
     * Input arguments : void
     * Return value    : void
     */
    void setAllocateResource(){
        Scanner sc = new Scanner(System.in);
        try {
            for (int i = 0; i < NOP; i++) {
                for (int j = 0; j < NOR; j++) {
                    CurrentRes[i][j] = sc.nextInt();
                }
            }
        } catch (Exception e) {
            System.out.println("PLeas enter integer values...");
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    /**
     * This method is used to check if there is any deadlock in the system
     * Input arguments : void
     * Return value    : boolean
     */
    boolean isDeadlock(){
        for (int i = 0; i < NOP; i++) {
            boolean isDeadlock = false;
            for (int j = 0; j < NOR; j++) {
                if((MaxRequiredRes[i][j] - CurrentRes[i][j])>Available[j]){
                    isDeadlock = true;
                    break;
                }
            }
            if(!isDeadlock)
                return false;
        }
        return true;
    }
    
    
    /**
     * This method is responsible for checking if the resources could be
     * allocated for process and if no it returns false else it allocates the resources
     * and return true
     * input arguments : int - process Number
     * Return value    : boolean
     */
    boolean isAllocateResources(int ProcessNo){
        for(int j = 0; j< NOR; j++){
            if((MaxRequiredRes[ProcessNo][j] - CurrentRes[ProcessNo][j])>Available[j])
                return false;
        }
        for(int j = 0; j< NOR; j++){
            int buf = MaxRequiredRes[ProcessNo][j] - CurrentRes[ProcessNo][j];
            Available[j] -= buf;
            CurrentRes[ProcessNo][j] +=buf;
        }
        return true;
    }
    
    /**
     * This method will simply deallocate the resources of the given process
     * input arguments : int - process Number
     * Return value    : void
     */
    void deAllocateResource(int ProcessNo){
        for(int j = 0; j< NOR; j++){
            int buf = CurrentRes[ProcessNo][j];
            Available[j] += buf;
            CurrentRes[ProcessNo][j] -=buf;
        }
    }
    
    /**
     * This method contains the logic for processes to run if there is no deadlock
     * input arguments : void
     * return value    : void
     */
    void RunAlgorithm(){
        int TerminatedProcess = 0;
        while(TerminatedProcess < NOP){
            for(int i = 0; i < NOP; i++){
                if(isAllocateResources(i)){
                    System.out.println("Max resources allocated for process : "+ i);
                    System.out.println("Processing the process : "+ i);
                    System.out.println("Process : " + i + " has finished completing and is now releasing the resources...");
                    deAllocateResource(i);
                    TerminatedProcess++;
                }
                if(TerminatedProcess==NOP)
                    break;
            }
        }
    }
}
