/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankersalgorithm;

import java.util.Scanner;

/**
 *
 * @author Chand
 */
public class BankersAlgorithmImpl {
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of processes : ");
        int NoOfProcesses = sc.nextInt();
        System.out.println("Enter the number of Resources : ");
        int NoOfResources = sc.nextInt();
        int MaxResources[] = new int[NoOfResources];
        System.out.println("Enter the existing resouces vector : \n");
        for(int i = 0; i< NoOfResources; i++){
            MaxResources[i] = sc.nextInt();
        }
        BankersAlgorithm b = new BankersAlgorithm(MaxResources, NoOfProcesses);
        b.start();
    }
}
