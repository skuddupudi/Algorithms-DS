/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServerCalc;

import CORBACalculator.Calculator;
import CORBACalculator.CalculatorHelper;
import CORBACalculator.CalculatorPOA;
import CORBACalculator.CalculatorPackage.DivisionByZeroEx;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.omg.CORBA.Context;
import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CORBA.Object;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.ServantNotActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;

/**
 *
 * @author CHAND
 */
class CalcServerImpl extends CalculatorPOA {

    ORB orb;

    void setorb(ORB orbval) {
        orb = orbval;
    }

    @Override
    public float Calculate(int opcode, float input1, float input2) throws DivisionByZeroEx {
        switch (opcode) {
            case 1:
                return (input1 + input2);
            case 2:
                return (input1 - input2);
            case 3:
                return (input1 * input2);
            case 4:
                if (input2 != 0) {
                    return (input1 / input2);
                } else //Try to write to the client division with zero not allowed
                {
                    DivisionByZeroEx ex = new DivisionByZeroEx();
                    throw ex;
                }
            default: {
                //Try to return message to th user
                return -1;
            }
        }

    }

    @Override
    public void exit() {
        try {
            orb.shutdown(false);
            orb.destroy();
        } catch (Exception e) {
        }
    }

}

public class CalcServer {

    public static void main(String[] args) {
        //Create an ORB
        try {
            ORB orb = ORB.init(args, null);

            //Create POA
            //1. Create Root POA and activate it
            POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
            rootPOA.the_POAManager().activate();

            //2. Create servant
            CalcServerImpl calc = new CalcServerImpl();
            calc.setorb(orb);

            //3. Create Object Reference
            org.omg.CORBA.Object ObjRef = rootPOA.servant_to_reference(calc);
            Calculator CalcRef = CalculatorHelper.narrow(ObjRef);

            //4. Get the NamingContextExt from the orb
            org.omg.CORBA.Object ObjNaming = orb.resolve_initial_references("NameService");
            NamingContextExt ncExt = NamingContextExtHelper.narrow(ObjNaming);

            //5. Bind a name to CalcRef using ncExt
            String name = "Mycalculator";
            NameComponent[] path = ncExt.to_name(name);
            ncExt.rebind(path, CalcRef);

            System.out.println("*************************************************");
            System.out.println("*                                               *");
            System.out.println("*  Server has been started successfully...!!!   *");
            System.out.println("*                                               *");
            System.out.println("*************************************************");
            //Wait for the Client to make some request
            orb.run();

        } //Handle Exceptoins
        catch (InvalidName ex) {
            ex.printStackTrace();
        } catch (AdapterInactive ex) {
            ex.printStackTrace();
        } catch (ServantNotActive ex) {
            ex.printStackTrace();
        } catch (WrongPolicy ex) {
            ex.printStackTrace();
        } catch (org.omg.CosNaming.NamingContextPackage.InvalidName ex) {
            ex.printStackTrace();
        } catch (NotFound ex) {
            ex.printStackTrace();
        } catch (CannotProceed ex) {
            ex.printStackTrace();
        }

    }
}
