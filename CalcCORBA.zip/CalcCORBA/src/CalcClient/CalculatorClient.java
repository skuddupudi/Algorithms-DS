/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CalcClient;

import CORBACalculator.Calculator;
import CORBACalculator.CalculatorHelper;
import CORBACalculator.CalculatorPackage.DivisionByZeroEx;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;

/**
 *
 * @author CHAND
 */
public class CalculatorClient {

    static Calculator MyCalc;

    public static void main(String[] args) {
        boolean isExit = false;

        try {
            //Create ORB
            ORB orb = ORB.init(args, null);

            //Get the naming Context
            org.omg.CORBA.Object NamingRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncExt = NamingContextExtHelper.narrow(NamingRef);
            
            //Look up for my calculator
            String name = "Mycalculator";
            MyCalc = CalculatorHelper.narrow(ncExt.resolve_str(name));

            while(!isExit) {
                //Take input for the first string
                System.out.print("Input : ");
                Scanner sc = new Scanner(System.in);
                String expr = sc.next();
                if ((expr.equals("exit")) || (expr.equals("Exit")) || expr.equals("EXIT")) {
                    isExit = true;
                    MyCalc.exit();
                    break;
                } else {
                    //Get the inputs for the operation
                    float input1 = sc.nextFloat();
                    float input2 = sc.nextFloat();
                    int opcode = 0;
                    //Assign the opcode for the appropriate operator
                    switch (expr) {
                        case "+":
                            opcode = 1;
                            break;
                        case "-":
                            opcode = 2;
                            break;
                        case "*":
                            opcode = 3;
                            break;
                        case "/":
                            opcode = 4;
                            break;
                        case "%":
                            opcode = 5;
                            break;
                        default :
                            System.out.println("Please give a proper operator");
                    }
                    // Call the function at the server
                    float result = MyCalc.Calculate(opcode, input1, input2);
                    System.out.println("Result : " + result);
                }

            }

         
        }
        //Catch exceptions
        catch (InvalidName ex) {
            ex.printStackTrace();
        } catch (NotFound ex) {
            ex.printStackTrace();
        } catch (CannotProceed ex) {
            ex.printStackTrace();
        } catch (org.omg.CosNaming.NamingContextPackage.InvalidName ex) {
            ex.printStackTrace();
        } catch (DivisionByZeroEx ex) {
            System.out.println(ex.message);
        }
    }
}
